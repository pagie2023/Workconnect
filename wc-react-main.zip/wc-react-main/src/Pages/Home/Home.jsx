import React from 'react'
import Sidebar from '../../components/Sidebar/Sidebar'

const Home = () => {
  return (
    <div style={{backgroundColor:'#F6FCFF', height:'96vh'}}>
      <Sidebar />
    </div>
  )
}

export default Home
