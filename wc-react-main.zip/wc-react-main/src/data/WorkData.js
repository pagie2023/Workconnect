// // import axios from 'axios'

// const API_URL = "http://127.0.0.1:8000/accounts/api/experience";

// export const experienceData = async () => {

//   // const result = []
//     await fetch(API_URL, {mode:'no-cors'})
//         .then((response) => {
//            response.json();
//         })
//         .then((data) => {
//           console.log(data)
//           // result = data
//         })
//         .catch((error) => console.log(error));
//         // console.log(result);
//   // return result;  
// };

// experienceData();



// /*export const WorkData = [
//   {
//     id: 1,
//     title: "WordPress",
//     subtitle: "University of Tresa",
//     dateInicio: "2020",
//     dateFin: "2022",
//     text: "University of Tresa institute of college of true",
//     stillWorkin: false,
//   },
// ];*/
