export const LanguageData = [
  {
    id: 1,
    language: "English",
    level: "Conversational",
  },
];
