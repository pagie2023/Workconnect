export const ResultsData = [
  {
    id: 1,
    title: " Project Manager for Development Team",
    text: "Sample Tech, Inc.",
    work: "Full time (Remote)",
    place: " groningen",
    month: "Aug.",
    day: "1",
    year: 2022,
    time: "3.00 pm",
  },
];
