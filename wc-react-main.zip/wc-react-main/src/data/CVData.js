export const CVData = [
  {
    id: 1,
    files: {
      name: {
        file: {
          path: "Curriculum Test",
          lastModified: 12345,
          lastModifiedDate: Date(),
          name: "Curriculum Test",
          size: 12345,
          type: "application/pdf",
          webkitRelativePath: "",
        },
      },
    },
  },
];
