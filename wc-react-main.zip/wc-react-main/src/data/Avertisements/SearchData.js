export const SearchData = [
  {
    id: 1,
    city: "Amsterdam",
    results: 220,
  },
  {
    id: 2,
    city: "Roterdam",
    results: 230,
  },
  {
    id: 3,
    city: "Utrecht",
    results: 240,
  },
  {
    id: 4,
    city: "Groningen",
    results: 230,
  },
  {
    id: 5,
    city: "Eindhoven",
    results: 210,
  },
  {
    id: 6,
    city: "Maastricht",
    results: 240,
  },
  {
    id: 7,
    city: "Breda",
    results: 230,
  },
  {
    id: 8,
    city: "Leiden",
    results: 200,
  },
  {
    id: 9,
    city: "Amsterdam",
    results: 220,
  },
  {
    id: 10,
    city: "Roterdam",
    results: 230,
  },
  {
    id: 11,
    city: "Utrecht",
    results: 240,
  },
  {
    id: 12,
    city: "Groningen",
    results: 230,
  },
  {
    id: 13,
    city: "Eindhoven",
    results: 210,
  },
  {
    id: 14,
    city: "Maastricht",
    results: 240,
  },
  {
    id: 15,
    city: "Breda",
    results: 230,
  },
  {
    id: 16,
    city: "Leiden",
    results: 200,
  },
];
