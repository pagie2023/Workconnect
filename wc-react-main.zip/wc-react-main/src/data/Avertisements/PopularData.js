export const PopularData = [
  {
    id: 1,
    titulo: "iOS",
  },
  {
    id: 2,
    titulo: "Development",
  },
  {
    id: 3,
    titulo: "Management",
  },
  {
    id: 4,
    titulo: "JavaScript",
  },
  {
    id: 5,
    titulo: "Software",
  },
  {
    id: 6,
    titulo: "iOS",
  },
  {
    id: 7,
    titulo: "Development",
  },
  {
    id: 8,
    titulo: "Management",
  },
  {
    id: 9,
    titulo: "JavaScript",
  },
  {
    id: 10,
    titulo: "Software",
  },
  {
    id: 11,
    titulo: "iOS",
  },
  {
    id: 12,
    titulo: "Development",
  },
  {
    id: 13,
    titulo: "Management",
  },
  {
    id: 14,
    titulo: "JavaScript",
  },
  {
    id: 15,
    titulo: "Software",
  },
];
