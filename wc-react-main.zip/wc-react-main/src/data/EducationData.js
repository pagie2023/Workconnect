export const EducationData = [
  {
    id: 1,
    title: "Systems Engineer",
    subtitle: "United Virtual University",
    dateInicio: "2020",
    dateFin: "2022",
    text: "Master's Degree",
    stillStudyin: false,
  },
];
